package com.agv.control.entity.agv;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import lombok.Data;

/**
 * vehicle_basic_information
 * @author 
 */
@Data
public  class Agv implements Serializable {

    private Integer id;
    //小车编号
    private String agvnumber;
    //车辆型号
    private String agvtype;
    //ip地址
    private String agvip;
    //序列号
    private String agvid;
    //创建时间
    private Date createtime;
    //是否启用
    private Byte agvstatus;
    //是否激活
    private Byte agvactive;
    //所在地图
    private String agvmap;

    private static final long serialVersionUID = 1L;

}