package com.agv.control.Utils;

import java.util.Date;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.Data;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "control.jwt")
public class JwtUtils {

    private  JwtUtils(){
    };
    private static long  expire;

    /**
     * userName，创建一个token
     * @param userName
     * @return
     */

    public static String createToken(String userName,String password){
        String salt=""+password.charAt(0);
        Md5Hash md5Hash=new Md5Hash(password,salt,2);
        String secret= String.valueOf(md5Hash);
        Date offset = new Date(System.currentTimeMillis() + expire);
        Algorithm algorithm = Algorithm.HMAC256(secret);//使用算法加密secret密钥

        JWTCreator.Builder builder = JWT.create();
        String token = builder.withClaim("userName", userName)
                .withExpiresAt(offset)
                .sign(algorithm);
        return token;

    }
    /**
     * 通过token获取userId
     * @param token
     * @return
     */
    public  static String getUserName(String token){
        DecodedJWT decodedJWT = JWT.decode(token);
        String userName = decodedJWT.getClaim("userName").asString();
        return userName;
    }

    /**
     *验证密钥
     * @param token
     */
    public  static boolean verifierToken(String token,String userName,String secret){
        Algorithm algorithm =Algorithm.HMAC256(secret);//对密钥进行加密算法处理
        JWTVerifier verifier = JWT.require(algorithm)
                .withClaim("userName", userName)
                .build();
        try{
            verifier.verify(token);//验证密钥和token（加密后的密钥部分）是否一致---sign
            return true;
        }catch (Exception e){
            return false;
        }
    }



}
