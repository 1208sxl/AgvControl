package com.agv.control.config.mqtt;

import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageProducer;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.*;

import java.util.UUID;


@Configuration
@IntegrationComponentScan
public class MqttInBoundConfiguration {
    private static Logger LOGGER= LoggerFactory.getLogger(MqttInBoundConfiguration.class);

    @Autowired
    private MqttConfiguration mqttProperaties;

    @Bean
    public MessageChannel mqttInputChannel(){
        return  new DirectChannel();
    }


    @Bean
    public MqttPahoClientFactory mqttClient() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();

        // mqtt用户名&密码
        String[] mqttServerUrls=mqttProperaties.getUrl().split(",");
        // mqtt服务地址，可以是多个
        options.setServerURIs(mqttServerUrls);
        options.setUserName(mqttProperaties.getUsername());
        options.setPassword(mqttProperaties.getPassword().toCharArray());
        options.setKeepAliveInterval(2);

        //接受离线消息
        options.setCleanSession(false);
        factory.setConnectionOptions(options);

        return factory;
    }

  /**
   *@description 接收消息 配置Client,监听Topic
   *@param
   *@return
   *@author  yudie
   *@Date  2022/11/17
   */
    @Bean
    public MessageProducer inbound(MqttPahoClientFactory mqttClient) {

        // 最后的#相当于通配符的概念
        String[] topic = mqttProperaties.getTopics().split(",");
        MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(
                mqttProperaties.getClientId(),
                mqttClient,
                topic);

        adapter.setCompletionTimeout(1000*5);
        adapter.setQos(0);

        adapter.setConverter(new DefaultPahoMessageConverter());
        adapter.setOutputChannel(mqttInputChannel());

        return adapter;
    }


    @Bean
    @ServiceActivator(inputChannel = "mqttInputChannel")
    public MessageHandler handler() {

        return new MessageHandler() {
            @Override
            public void handleMessage(Message<?> message) throws MessagingException {
                Object payload=message.getPayload();
                MessageHeaders messageHeaders=message.getHeaders();
                UUID packetId=messageHeaders.getId();
                Object qos=messageHeaders.get(MqttHeaders.QOS);
                Object recvTopic=messageHeaders.get(MqttHeaders.RECEIVED_TOPIC);
                String handMessage="MQTT Client package ID==>"+packetId
                        +"\nparload"+payload
                        +"\nTopics"+recvTopic;
                LOGGER.debug(handMessage);
                System.out.println(handMessage);

            }

        };
    }


}
