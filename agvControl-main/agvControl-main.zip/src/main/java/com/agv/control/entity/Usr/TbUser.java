package com.agv.control.entity.Usr;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * tb_user
 * @author 
 */
@Data
public class TbUser implements Serializable {
    private Integer id;

    private String usrname;

    private String password;

    private Integer roleid;

    private Long logCnt;

    private String phoneNumber;

    private Date logDate;

    private static final long serialVersionUID = 1L;
}