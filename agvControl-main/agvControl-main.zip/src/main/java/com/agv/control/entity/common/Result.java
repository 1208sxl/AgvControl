package com.agv.control.entity.common;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Result {

    /** 状态 */
    private Integer result;
    /** 消息 */
    private String msg;
    /** 数据 */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Object data;

    private long total;

    public Result(){

    }

    public Result(Integer result, String msg, Object data){
        this.result = result;
        this.msg = msg;
        this.data = data;
    }

    public Result(Integer result, String msg, Object data, long total){
        this.result = result;
        this.msg = msg;
        this.data = data;
        this.total = total;
    }

    public Integer getResult() {
        return result;
    }
    public void setResult(Integer result) {
        this.result = result;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getdata() {
        return data;
    }

    public void setdata(Object data) {
        this.data = data;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }


}
