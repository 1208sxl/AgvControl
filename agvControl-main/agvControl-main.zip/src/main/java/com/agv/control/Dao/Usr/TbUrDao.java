package com.agv.control.Dao.Usr;

import com.agv.control.entity.Usr.TbUr;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TbUrDao {
    int deleteByPrimaryKey(Integer uid);

    int insert(TbUr record);

    int insertSelective(TbUr record);

    TbUr selectByPrimaryKey(Integer uid);

    int updateByPrimaryKeySelective(TbUr record);

    int updateByPrimaryKey(TbUr record);
}