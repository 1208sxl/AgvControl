package com.agv.control.Dao.agv;

import com.agv.control.entity.agv.Agv;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AgvMapper {

    List<Agv> listAgv();

    int deleteByPrimaryKey(Integer id);

    int insert(Agv agv);

    Agv selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(Agv agv);
}