package com.agv.control.web.mqtt;
import com.agv.control.Utils.BaseController;
import com.agv.control.entity.agv.Agv;
import com.agv.control.service.agvservice.AgvService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/")
public class AgvManager extends BaseController {
    @Autowired
    private AgvService AgvService;

    @ApiOperation("添加Agv")
    @RequestMapping(value="/addagv.action", method = RequestMethod.POST)
    public @ResponseBody
    Object AddAgv(@RequestBody Agv agv) {
        int res = AgvService.insert(agv);
        if (res==1){
            return  buildSucces(agv);
        }else{
            return buildError("添加失敗");
        }
    }

    @ApiOperation("删除Agv")
    @RequestMapping(value="/deleteagv.action", method = RequestMethod.POST)
    public @ResponseBody
    Object DeleteAgv(Integer id) {
        int res=AgvService.deleteByPrimaryKeys(id);
        if(res==1){
            return  buildSucces("刪除成功");
        }
        else{
            return buildError("刪除失敗");
        }
    }

    @ApiOperation("更新Agv")
    @RequestMapping(value="/updateagv.action", method = RequestMethod.POST)
    public @ResponseBody
    Object UpdateAgv(Agv agv) {
        int res=AgvService.updateByPrimaryKey(agv);
        if(res==1){
            return  buildSucces(agv);}
        else{
            return buildError("更新失敗");
        }
    }

    @ApiOperation("选择Agv")
    @RequestMapping(value="/selectagv.action", method = RequestMethod.POST)
    public @ResponseBody
    void SelectAgv(Integer id) {
        AgvService.selectByPrimaryKey(id);
        buildSucces();
    }



}
