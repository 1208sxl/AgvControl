package com.agv.control.web;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import com.agv.control.Utils.BaseController;
import com.agv.control.Utils.JwtUtils;
import com.agv.control.service.User.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

@Api(value = "用户相关接口")
@RestController
@RequestMapping(value = "/")
public class UserController extends BaseController {
    @Autowired
    private UserService userService;

    @ApiOperation("用户登录")
    @RequestMapping(value="/doLogin.action", method = RequestMethod.POST)
    public @ResponseBody
    Object doLogin(String userName, String password) {
        String msg = userService.Login(userName, password);
            if( "SUC".equals(msg)){
                String token= JwtUtils.createToken(userName,password);
                HashMap<String,String> result=new HashMap<>();
                result.put("token",token);
                result.put("user",userName);
                return super.buildSucces(result);
            }else{
                return super.buildError(msg);
            }
    }

    /**
     * @date 2022/10/5
     * @author yd
     * @param response
     * @param session
     * @throws IOException
     */
    @ApiOperation("获取验证码")
    @RequestMapping(value="/getValideCode.action", method = RequestMethod.GET)
    public @ResponseBody
    void getValideCode(HttpServletRequest request,HttpServletResponse response, HttpSession session) throws IOException {
        LineCaptcha lineCaptcha= CaptchaUtil.createLineCaptcha(116,36,4,10);
        session.setAttribute("code",lineCaptcha.getCode());
        try{
            ServletOutputStream outputStream = response.getOutputStream();
            lineCaptcha.write(outputStream);
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * @author yd
     * @param usrname  用户名
     * @param password  密码
     */
    @ApiOperation("用户注册")
    @RequestMapping(value="/doRegister.action", method = RequestMethod.POST)
    public @ResponseBody
    Object doRegister(String usrname,String password)  {
        int res=userService.doRegister(usrname, password);
        if(res>0) {
            return super.buildSucces();
        }else{
            String msg="注册失败";
            return super.buildError(msg);
        }
    }
}
