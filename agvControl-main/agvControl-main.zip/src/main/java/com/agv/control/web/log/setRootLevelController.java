package com.agv.control.web.log;


import com.agv.control.Utils.BaseController;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;

import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.springframework.web.bind.annotation.*;




@RestController
@RequestMapping(value = "/")
public class setRootLevelController extends BaseController {
    /**
     * Log4j2 动态修改 root(根)日志级别，修改之后配置立刻生效.
     * http://localhost:port/log/setRootLevel?level=TRACE
     *
     * @param level ：可选值有：ALL、TRACE、DEBUG、INFO、WARN、ERROR、FATAL、OFF，否则默认会设置为 DEBUG，不区分大小写。
     * @return Map<String, Object>
     */


    @RequestMapping(value = "/log/setRootLevel", method = RequestMethod.POST)
    public @ResponseBody
    Object setRootLevel(@RequestParam(value = "level") String level) {
        try {
            LoggerContext loggerContext = (LoggerContext) LogManager.getContext(false);

            Configuration configuration = loggerContext.getConfiguration();

            LoggerConfig loggerConfig = configuration.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);

            Level toLevel = Level.toLevel(level);

            loggerConfig.setLevel(toLevel);

            loggerContext.updateLoggers();

            return super.buildSucces(LogManager.getRootLogger().getLevel().name());

        } catch (Exception e) {
            return super.buildError(e.getMessage());
        }
    }
}
