package com.agv.control.config.mqtt;

import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
import org.springframework.integration.mqtt.outbound.MqttPahoMessageHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;



@Configuration
public class MqttOutBoundConfiguration {
    @Autowired
    private MqttConfiguration mqttProperaties;
  /**
   *@description
   *@param
   *@return
   *@author  yudie
   *@Date  2022/11/17
   */

    @Bean
    public MessageChannel mqttOutboundChannel() {
        return new DirectChannel();
    }
    @Bean
    public MqttPahoClientFactory mqttOutClient() {
        DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
        MqttConnectOptions options = new MqttConnectOptions();

        // mqtt用户名&密码
        String[] mqttServerUrls=mqttProperaties.getUrl().split(",");
        // mqtt服务地址，可以是多个
        options.setServerURIs(mqttServerUrls);
        options.setUserName(mqttProperaties.getUsername());
        options.setPassword(mqttProperaties.getPassword().toCharArray());

        //接受离线消息
        options.setCleanSession(false);
        options.setAutomaticReconnect(true);
        factory.setConnectionOptions(options);

        return factory;
    }
    /**
     *@description 发送消息
     *@param
     *@return
     *@author  yudie
     *@Date  2022/11/17
     */
    @Bean
    @ServiceActivator(inputChannel = "mqttOutboundChannel")
    public MessageHandler outbound(MqttPahoClientFactory mqttOutClient) {
        MqttPahoMessageHandler messageHandler=new MqttPahoMessageHandler(mqttProperaties.getClientId()+"client_id",
                mqttOutClient);
        messageHandler.setDefaultTopic("agv");
        messageHandler.setAsync(true);
        return  messageHandler;
    }
}

