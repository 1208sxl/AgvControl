package com.agv.control.service.agvservice;

import com.agv.control.Dao.agv.AgvMapper;
import com.agv.control.entity.agv.Agv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class AgvService {


    @Autowired
    private AgvMapper mapper;

    public List<Agv> listAgv(){
        return mapper.listAgv();
    }

    public int deleteByPrimaryKeys(Integer id) {
        int res=mapper.deleteByPrimaryKey(id);
        return  res;
    }

    public int insert(Agv agv) {
        int res=mapper.insert(agv);
        return res;
    }

    public Agv selectByPrimaryKey(Integer id) {
        return mapper.selectByPrimaryKey(id);
    }

    public int updateByPrimaryKey(Agv agv) {
        int res=mapper.updateByPrimaryKey(agv);
        return res;
    }
}
