package com.agv.control.Dao.Usr;

import com.agv.control.entity.Usr.TbPermissions;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TbPermissionsDao {
    int deleteByPrimaryKey(Integer permissionId);

    int insert(TbPermissions record);

    int insertSelective(TbPermissions record);

    TbPermissions selectByPrimaryKey(Integer permissionId);

    int updateByPrimaryKeySelective(TbPermissions record);

    int updateByPrimaryKey(TbPermissions record);
}