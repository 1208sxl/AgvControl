package com.agv.control.Dao.Usr;

import com.agv.control.entity.Usr.TbRoles;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TbRolesDao {
    int deleteByPrimaryKey(Integer roleId);

    int insert(TbRoles record);

    int insertSelective(TbRoles record);

    TbRoles selectByPrimaryKey(Integer roleId);

    int updateByPrimaryKeySelective(TbRoles record);

    int updateByPrimaryKey(TbRoles record);
}