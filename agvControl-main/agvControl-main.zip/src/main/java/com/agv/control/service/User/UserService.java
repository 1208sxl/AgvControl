package com.agv.control.service.User;

import com.agv.control.Dao.Usr.TbUserDao;
import com.agv.control.entity.Usr.TbUser;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private TbUserDao tbUserDao;


    public TbUser getUserInfoByName(String name) {
        return tbUserDao.getUserInfoByName(name);
    }

    public String Login(String userName, String password) {
        String salt=""+password.charAt(0);
        Md5Hash md5Hash=new Md5Hash(password,salt,2);
        TbUser tbUser=tbUserDao.getUserInfoByName(userName);
        if(null==tbUser){
            return "用户不存在";
        }else if(!String.valueOf(md5Hash).equals(tbUser.getPassword())){
            return "密码错误";
        }else{
            return "SUC";
        }

    }

    public String shiroLogin(String userName, String password){
        UsernamePasswordToken token = new UsernamePasswordToken(userName, password, null);
        token.setRememberMe(true);
        // shiro登陆验证
        try {
            SecurityUtils.getSubject().login(token);
        } catch (UnknownAccountException ex) {
            return "账号不存在";
        } catch (IncorrectCredentialsException ex) {
            return "密码错误！";
        } catch (AuthenticationException ex) {
            String ret = null;
            Throwable t = ex;
            while(true){
                t = t.getCause();
                if(t == null || t.getCause() == null){
                    ret = t.getMessage();
                    break;
                }
            }
            return "系统错误：" + ret;
        } catch (Exception ex) {
            ex.printStackTrace();
            return "内部错误，请重试！";
        }
        return "登录成功";
    }

    public int doRegister(String usrname,String password){
        String salt=""+password.charAt(0);
        Md5Hash md5Hash=new Md5Hash(password,salt,2);
        TbUser tbUser=new TbUser();
        tbUser.setUsrname(usrname);
        tbUser.setPassword(String.valueOf(md5Hash));
        return tbUserDao.insert(tbUser);
    }


}
