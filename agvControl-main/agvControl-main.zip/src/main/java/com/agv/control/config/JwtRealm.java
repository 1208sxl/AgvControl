package com.agv.control.config;

import com.agv.control.Utils.JwtUtils;
import com.agv.control.Utils.JwtToken;


import com.agv.control.entity.Usr.TbUser;
import com.agv.control.service.User.UserService;

import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;

import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;

import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

public class JwtRealm extends AuthorizingRealm {

    private  final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Lazy
    @Autowired
    private UserService userService;

//    @Autowired
//    private RoleService roleService;
//    @Autowired
//    private PermissionService permissionService;

    /**
     * 授权查询回调函数, 进行鉴权但缓存中无用户的授权信息时调用,负责在应用程序中决定用户的访问控制的方法
     * 获取授权操作(将当前用户的角色和权限信息查询出来)
     */

    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof JwtToken;
    }


    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String username=(String) principalCollection.iterator().next();
        //根据用户名查询角色列表和权限列表
//        Set<String> roleNames=roleService.getUserRoleInfoByName(username);
//        Set<String> ps=permissionService.getUserPsInfoByName(username);

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
//        info.setRoles(roleNames);
//        info.setStringPermissions(ps);
        return info;
    }

    /**
     * 认证回调函数，登录信息和用户验证信息验证
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        // 把token转换成User对象
        String token = (String) authenticationToken.getCredentials();

        String username = JwtUtils.getUserName(token);
        if (null==username) {
            throw new AuthenticationException("token错误!");
        }
        TbUser tbUser=userService.getUserInfoByName(username);

        if(null==tbUser){
            throw new AuthenticationException("用户不存在!");
        }
        try {
            JwtUtils.verifierToken(token,username,tbUser.getPassword());
            return new SimpleAuthenticationInfo(token, token, getName());
        } catch (TokenExpiredException e) {
            throw new AuthenticationException("token已过期!");
        } catch (SignatureVerificationException e) {
            throw new AuthenticationException("密码不正确!");
        }
    }

    public void clearCached() {
        this.clearCachedAuthorizationInfo(SecurityUtils.getSubject().getPrincipals());
    }
}