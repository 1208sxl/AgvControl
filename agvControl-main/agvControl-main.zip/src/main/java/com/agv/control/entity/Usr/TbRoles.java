package com.agv.control.entity.Usr;

import java.io.Serializable;
import lombok.Data;

/**
 * tb_roles
 * @author 
 */
@Data
public class TbRoles implements Serializable {
    private Integer roleId;

    private String roleName;

    private static final long serialVersionUID = 1L;
}