package com.agv.control.service.User;

import org.springframework.stereotype.Service;

@Service
public class RoleService {
}
