package com.agv.control.web.mqtt;


import com.agv.control.service.mqtt.MqttGateWayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/")
public class MqttController {
    @Autowired
    private MqttGateWayService gateWay;


    @RequestMapping(value = "/sendMqtt",method = RequestMethod.POST)
    @ResponseBody
    /**
     *@description 发送mqtt消息
     *@param  [data, topic]
     *@return  java.lang.Object
     *@author  yudie
     *@Date  2022/11/16
     */
    public Object sendMqtt(String data,String topic){
        try {
            gateWay.sendMessageToMqtt(data,topic);
            return data;
        }catch (Exception e){

        }
        return "fail";
    }

}
