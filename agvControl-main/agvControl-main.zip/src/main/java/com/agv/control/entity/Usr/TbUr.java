package com.agv.control.entity.Usr;

import java.io.Serializable;
import lombok.Data;

/**
 * tb_ur
 * @author 
 */
@Data
public class TbUr implements Serializable {
    private Integer uid;

    private Integer rid;

    private static final long serialVersionUID = 1L;
}