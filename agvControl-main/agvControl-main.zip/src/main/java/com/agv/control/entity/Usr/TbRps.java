package com.agv.control.entity.Usr;

import java.io.Serializable;
import lombok.Data;

/**
 * tb_rps
 * @author 
 */
@Data
public class TbRps implements Serializable {
    private Integer rid;

    private Integer pid;

    private static final long serialVersionUID = 1L;
}