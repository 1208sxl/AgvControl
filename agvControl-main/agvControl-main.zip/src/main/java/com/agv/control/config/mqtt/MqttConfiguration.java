package com.agv.control.config.mqtt;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 *@description mqtt链接配置
 *@param
 *@return
 *@author  yudie
 *@Date  2022/11/17
 */
@Configuration
@ConfigurationProperties(prefix = "com.mqtt")
@Data
public class MqttConfiguration {
    private  String url;
    private String clientId;
    private String topics;
    private  String username;
    private  String password;
    private String timeout;
    private String keepalive;}
