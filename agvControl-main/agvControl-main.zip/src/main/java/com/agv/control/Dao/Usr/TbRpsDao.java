package com.agv.control.Dao.Usr;

import com.agv.control.entity.Usr.TbRps;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TbRpsDao {
    int deleteByPrimaryKey(Integer rid);

    int insert(TbRps record);

    int insertSelective(TbRps record);

    TbRps selectByPrimaryKey(Integer rid);

    int updateByPrimaryKeySelective(TbRps record);

    int updateByPrimaryKey(TbRps record);
}