package com.agv.control.service.mqtt;

import org.springframework.integration.annotation.MessagingGateway;
import org.springframework.integration.mqtt.support.MqttHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

//发布者

@Service
@MessagingGateway(defaultRequestChannel = "mqttOutboundChannel")
public interface MqttGateWayService {

    void sendMessageToMqtt(String data);
    /**
     * 指定topic消息发送
     *
     * @param topic   指定topic
     * @param data 消息payload
     */
    void sendMessageToMqtt(String data, @Header(MqttHeaders.TOPIC)String topic);

    void sendMessageToMqtt(String data, @Header(MqttHeaders.TOPIC)String topic,@Header(MqttHeaders.QOS) int qos);

}
