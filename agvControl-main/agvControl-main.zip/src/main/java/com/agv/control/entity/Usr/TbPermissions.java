package com.agv.control.entity.Usr;

import java.io.Serializable;
import lombok.Data;

/**
 * tb_permissions
 * @author 
 */
@Data
public class TbPermissions implements Serializable {
    private Integer permissionId;

    private String permissionCode;

    private String permissionName;

    private static final long serialVersionUID = 1L;
}