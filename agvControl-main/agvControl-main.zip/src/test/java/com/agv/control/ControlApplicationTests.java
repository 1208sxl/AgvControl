package com.agv.control;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlApplicationTests {

    @Test
    void contextLoads() {
    }

}
